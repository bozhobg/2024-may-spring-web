package com.paintingscollectors.model.enums;

public enum StyleName {
    IMPRESSIONISM, ABSTRACT, EXPRESSIONISM, SURREALISM, REALISM
}
